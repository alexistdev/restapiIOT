package com.example.retrofitlibrary.model

class QuestionList {
    val items: List<Question>? = null
    val has_more: Boolean? = null
    val quota_max: Number? = null
    val quota_remaining: Number? = null
}
